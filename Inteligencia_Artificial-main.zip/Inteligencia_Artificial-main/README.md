https://www.tensorflow.org/tutorials/keras/classification?hl=pt-br

https://github.com/tensorflow/docs-l10n/blob/master/site/pt-br/tutorials/keras/classification.ipynb
